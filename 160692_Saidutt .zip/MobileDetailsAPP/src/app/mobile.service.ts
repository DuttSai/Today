import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Mobile } from './mobile';

@Injectable()
export class MobileService {
  tempArr: any[] = []; //sample array for storing id/name/price
  samArr: Mobile[] = []; //sorting the required field (id/name/price)
  i: number; // temporary variable
  j: number; // temporary variable
  mob1:number=0;
  constructor(private http: HttpClient) { }
  getMobileDetails(): any {
    return this.http.get('/assets/Mobile.json')

  }
  idClick(mobileArr: Mobile[]) {
    this.i = 0;
    this.j = 0;
    console.log("id clicked")
    // this map function is used for copying  the Id of array in a new Array(tempArr)
    mobileArr.map(x => {
      this.tempArr.push(x.id)
    })
    // Sorting the newely created Array(tempArr) which contains Ids of employee Array in sorted order
    this.tempArr.sort()
    console.log("======== Soritng the array by ID=================")
    // Here sorting the employee array by using temp array (tempArr) 
    for (let t = 0; t <= mobileArr.length; t++) {
      for (let a of mobileArr) {
        if (a.id == this.tempArr[this.i]) {
          console.log(a);
          // Assinging the sorted data in another array (samArr)
          this.samArr[this.j] = a;
          this.j++
        }

      }
      this.i++
    }
    this.i = 0
    // Finally assinging the sorted data in Employee Array
    mobileArr.map(m => {
      mobileArr[this.i] = this.samArr[this.i]
      this.i++
    })
    this.tempArr = [] //making this temporary array empty for other functions usage
    return mobileArr
  }
  nameClick(mobileArr: Mobile[]) {
    this.i = 0;
    this.j = 0;
    console.log("name clicked")
    // this map function is used  for copying  the Names of array in a new Array(tempArr)
    mobileArr.map(x => {
      this.tempArr.push(x.mobileName)
    })
    // Sorting the newely created Array (tempArr) which contains Ids of employee Array
    this.tempArr.sort()
    console.log("======== Soritng the array by Name=================")
    // Here sorting the employee array by using temp array (tempArr) 
    for (let t = 0; t <= mobileArr.length; t++) {
      for (let a of mobileArr) {
        if (a.mobileName == this.tempArr[this.i]) {
          console.log(a);
          // Assinging the sorted data in another array (samArr)
          this.samArr[this.j] = a;
          this.j++
        }

      }
      this.i++
    }
    this.i = 0
    // Finally assinging the sorted data in Employee Array
    mobileArr.map(m => {
      mobileArr[this.i] = this.samArr[this.i]
      this.i++
    })
    this.tempArr = [] // making this array 
    return mobileArr
  }
  priceClick(mobileArr: Mobile[]) {
    this.i = 0;
    this.j = 0;
    console.log("Price clicked")
    // this map function is used for copying  the Id of array in a new Array(tempArr)
    mobileArr.map(x => {
      
      this.tempArr.push(Number(x.mobilePrice))
    })
    console
    // Sorting the newely created Array(tempArr) which contains Ids of employee Array
    for(let i=0;i<this.tempArr.length;i++)
    {
      for(let j=i+1;j<this.tempArr.length;++j)
      {
        
        if(this.tempArr[i] > this.tempArr[j])
        {
          
          this.mob1=this.tempArr[i]
         this.tempArr[i] = this.tempArr[j];
          this.tempArr[j]=this.mob1;
        }
       
      }
    } // hence reversing it for ascending order
    console.log("======== Soritng the array by Price=================")
    console.log(this.tempArr)
    // Here sorting the employee array by using temp array (tempArr) 
    for (let t = 0; t <= mobileArr.length; t++) {
      for (let a of mobileArr) {
        if (a.mobilePrice == this.tempArr[this.i]) {
          console.log(a);
          // Assinging the sorted data in another array (samArr)
          this.samArr[this.j] = a;
          this.j++
        }

      }
      this.i++
    }
    this.i = 0
    // Finally assinging the sorted data in Employee Array
    mobileArr.map(m => {
      mobileArr[this.i] = this.samArr[this.i]
      this.i++
    })
    this.tempArr = [] //making this empty for other functions usage
    return mobileArr
  }


}

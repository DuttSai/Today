export class Mobile {
    id:number;
    mobileName:string;
    mobilePrice:number;
}

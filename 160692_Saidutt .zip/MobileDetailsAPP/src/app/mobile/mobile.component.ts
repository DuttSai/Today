import { Component, OnInit } from '@angular/core';
import { Mobile } from '../mobile';
import { MobileService } from '../mobile.service';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css'],
  providers:[MobileService]
})
export class MobileComponent implements OnInit {
mobileArr:Mobile[]=[]
  constructor(private mobileService:MobileService) { }

  ngOnInit() {
    this.mobileService.getMobileDetails().subscribe((mDetails:Mobile[])=>this.mobileArr=mDetails)
  }
  delMobData(i:number):any{
    return this.mobileArr.splice(i,1);

}
idClick(){
  this.mobileArr=this.mobileService.idClick(this.mobileArr)
}
nameClick(){
  this.mobileArr=this.mobileService.nameClick(this.mobileArr)
}
priceClick(){
  this.mobileArr=this.mobileService.priceClick(this.mobileArr)
}
}

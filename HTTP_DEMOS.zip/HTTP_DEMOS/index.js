var http=require("http")
var request=require("./request")
var server=http.createServer(request.requestHandler)
server.listen(5000,err=>{
    if(err){
        console.log("could not start server")
        return
    }
    console.log("started server")

})
const express=require("express");
var router=express.Router()
var products=[
    {id:1,name:'Apple',quantity:20,price:555555},
    {id:1,name:'Lenovo',quantity:108,price:5555552424},
    {id:1,name:'Samsung',quantity:50,price:5555554242},
    {id:1,name:'Realme',quantity:500,price:5555550555}
]
router.get("/list",(req,res)=>{
    var model={
        caption:"Products List",
        items:products
    }
    res.header("content-type","text/html").render("product-list",model)
})
router.get("/add",(req,res)=>{
    res.header("content-type","text/html").render("product-add")
})
module.exports=router
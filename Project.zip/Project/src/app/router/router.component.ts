import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmpserviceService } from '../empservice.service';

@Component({
  selector: 'app-router',
  templateUrl: './router.component.html',
  styleUrls: ['./router.component.css']
})
export class RouterComponent implements OnInit {

  constructor(private empservice:EmpserviceService) { }
  empArr:Emp[]
  ngOnInit() {
this.empservice.getEmp().subscribe((data)=>this.empArr=data)
  }
  
  

  

}
// module.exports=RouterComponent
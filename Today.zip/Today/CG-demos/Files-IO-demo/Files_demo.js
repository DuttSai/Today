var fs =require("fs")
var path =require("path")
exports.wrteContent=(filename,content)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
    fs.open(filepath,'w',(err,fd)=>{
        if(err){
            console.log("Failed to open")
            return
        }
        fs.write(fd,Buffer.from(content),(err,noOfBytes,buff)=>{
            if(err){
                console.log("Failed to write")
                return
            }
            console.log("Successfully written the content")
            fs.close(fd,(err)=>{
                if(err)
                {
                    console.log("File is not closed")
                return
            }
            })
            console.log("File closed")

        })

    })
}
exports.readContent=(filename,cb)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
    fs.open(filepath,"r",(err,fd)=>{
        if(err){
            console.log("Failed to open file")
            return
        }
        fs.read(fd,Buffer.alloc(1024),0,1024,0,(err,bytesread,buff)=>{
            if(err){
            console.log("Failed to read")
                return
            }
            console.log(buff.toString())
            fs.close(fd,err=>{
                if(err){
            console.log("Failed to close File")
                    return
                }
                console.log("File Closed")
            })
            cb(
                buff.toString().toUpperCase()
            )
            return buff.toString()
        })
    })

}
exports.writeContentSync=(filename,content)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
    var fd=fs.openSync(filepath,'w')
    if(!fd){
        console.log("Failed to open file")
        return
    }
    fs.writeSync(fd,Buffer.from(content))
    fs.closeSync(fd)
}
exports.readContentSync=(filename)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
var fd=fs.openSync(filepath,'r')
if(!fd){
    console.log("Failed to open")
    return
}
var res=Buffer.alloc(1024)
fs.readSync(fd,res,0,1024,0)
console.log(res.toString())
fs.closeSync(fd)
}

exports.writeFileContent=(filename,content)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
    fs.writeFile(filepath,content,(err)=>{
        if(err){
            console.log("Error in writing File")
            return
        }
        console.log("Successfully written in file");
    })
}
exports.readFileContent=(filename)=>{
    var filepath=path.resolve(__dirname,'Myfiles',filename)
fs.readFile(filepath,{encoding:'utf-8'},(err,data)=>{
    if(err){
        console.log("Error in opening File")
        return
    }
 console.log(data)

})
}
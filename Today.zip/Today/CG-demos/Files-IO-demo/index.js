// console.log(__dirname)
// console.log(__filename)
var path=require('path')
var fs=require("fs")
var fpath=path.resolve(__dirname,"Myfiles","message.txt")
console.log(fpath)
var {wrteContent,readContent,writeContentSync,readContentSync,writeFileContent,readFileContent}=require("./Files_demo")
var data="Hi, How are You !!!!!!!!!!!!!!!!!!!!!!!!!!"
var filename="message.txt"
// wrteContent(filename,data)
// var res=readContent(filename)
// console.log(res)
// readContent(filename,(res)=>{
// console.log(res)
// })
// var filename1="message2.txt"
// writeContentSync(filename1,data)
// readContentSync(filename1)
// var filenmae2="message3.txt";
// writeFileContent(filenmae2,data);
// readFileContent(filenmae2);
// fs.stat(fpath,(err,stat)=>{
//     if(err){
// console.log("error in opening a file")
// return
//     }
//     console.log(stat)
// })
// fs.watchFile(fpath,(curr,prev)=>{
//     console.log(curr.size+'========'+prev.size)
// })
var {readFromFileStream,writeToFileStream}=require('./StreamDemo')
// writeToFileStream("message4.txt",' HI HOW ARE YOU')
readFromFileStream("message4.txt")
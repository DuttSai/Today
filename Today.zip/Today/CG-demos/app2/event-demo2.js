var EventE=require("events").EventEmitter
var ee=new EventE();
ee.on("start",(pos)=>{
var i=pos;
console.log("Timer Started")
timer=setInterval(()=>{
    console.log(i)
    i++
},500)
})
ee.on("stop",()=>{
    console.log("stopping .....")
    clearInterval(timer)
})
ee.emit("start",100)
setTimeout(()=>{
ee.emit("stop")
// ee.emit("start",100)
},10000)
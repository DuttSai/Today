var buff=Buffer.from("sample data");
console.log(buff.toString());
var b=Buffer.alloc(7);
var noOfBytesWritten=b.write("This is  sample data")
console.log("Bytes Written  "+noOfBytesWritten)
console.log(b.toString())
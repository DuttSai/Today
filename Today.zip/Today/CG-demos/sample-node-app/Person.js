class Person{
    // firtsName
    // lastName
    constructor(){
        this.fristName="";
        this.lastName=""
    }
    getFullName(){
        return `${this.fristName} ${this.lastName} `
    }
}
module.exports=Person;
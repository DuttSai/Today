var PersonS=require('./Person')
var Calculator=require('./calculator')
var {getGoodMorn}=require('./greeting')
function sayHello(){
console.log("hello ................")
}
sayHello()

var a=5,b=3;
res=Calculator.mulFun(a,b)
console.log(` Product of ${a} and ${b} is :  ${res}`)

var person = new PersonS();
person.fristName="sai"
person.lastName="dutt"
var fullname=person.getFullName();
var greeting =getGoodMorn(fullname);
console.log(greeting)
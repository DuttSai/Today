import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmpserviceService } from '../empservice.service';

@Component({
  selector: 'app-router',
  templateUrl: './router.component.html',
  styleUrls: ['./router.component.css'],
})
export class RouterComponent implements OnInit {

  constructor(private empservice: EmpserviceService) { }

  private empArr: any;

  ngOnInit() {
    console.log(this.empservice.getEmp())

    this.empservice.getEmp()
      .subscribe(
        res => this.empArr = res
      );
  }
}